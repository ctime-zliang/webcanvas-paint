import { Camera } from '../common/Camera'
import { Matrix4 } from '../common/geometry/matrix/Matrix4'
import { Plane } from '../common/Plane'
import {
	TElementD2LineJSONData,
	TElementD2ArcJSONData,
	TElementD2CircleJSONData,
	TElementD2ImageJSONData,
	TElementD2PointJSONData,
	TElementD2TextJSONData,
} from '../types/Primitive'
import { DataBufferGL } from './buffer/DataBufferGL'
import { PrimitiveBlock, PrimitiveDataBuilderGL } from './buffer/PrimitiveDataBuilderGL'
import { D2ArcDataGL } from './primitives/d2Arc/D2ArcDataGL'
import { D2CircleDataGL } from './primitives/d2Circle/D2CircleDataGL'
import { D2ImageDataGL } from './primitives/d2Image/D2ImageDataGL'
import { D2LineDataGL } from './primitives/d2Line/D2LineDataGL'
import { D2PointDataGL } from './primitives/d2Point/D2PointDataGL'
import { D2TextDataGL } from './primitives/d2Text/D2TextDataGL'
import { PtType } from './primitives/PrimitiveGL'
import { PrimitiveProgramBuilderGL } from './program/PrimitiveProgramBuilderGL'
import { SceneGL } from './SceneGL'

export const MAX_PLANE_NUM: number = 1024

export class PlaneGL extends Plane {
	private _sceneGL: SceneGL
	private _dataBuilder: PrimitiveDataBuilderGL
	private _programBuilder: PrimitiveProgramBuilderGL
	private _elementsMap: Map<string, number>
	constructor(planeId: string, sceneGL: SceneGL) {
		super(planeId, sceneGL)
		this._sceneGL = sceneGL
		this._dataBuilder = new PrimitiveDataBuilderGL(this._sceneGL.webGL)
		this._programBuilder = new PrimitiveProgramBuilderGL(this._sceneGL.webGL)
		this._elementsMap = new Map()
	}

	public getScene(): SceneGL {
		return this.scene as SceneGL
	}

	public addD2ArcItems(targetPrimitives: Map<string, TElementD2ArcJSONData>): void {
		for (let [key, primitiveItemValueData] of targetPrimitives) {
			const id: number = this.addPrimitiveItem(D2ArcDataGL.createArrayData(primitiveItemValueData))
			this._elementsMap.set(key, id)
		}
	}
	public updateD2ArcItems(targetPrimitives: Map<string, TElementD2ArcJSONData>): void {
		for (let [key, primitiveItemValueData] of targetPrimitives) {
			const id: number = this._elementsMap.get(key)!
			this.updatePrimitiveItem(id, D2ArcDataGL.createArrayData(primitiveItemValueData))
		}
	}
	public deleteD2ArcItems(targetIds: Set<string>): void {
		const arrTargetIds: Array<string> = Array.from(targetIds)
		for (let i: number = 0; i < arrTargetIds.length; i++) {
			const primitiveId: number = this._elementsMap.get(arrTargetIds[i])!
			this.deletePrimitiveItem(primitiveId)
		}
	}

	public addD2CircleItems(targetPrimitives: Map<string, TElementD2CircleJSONData>): void {
		for (let [key, primitiveItemValueData] of targetPrimitives) {
			const id: number = this.addPrimitiveItem(D2CircleDataGL.createArrayData(primitiveItemValueData))
			this._elementsMap.set(key, id)
		}
	}
	public updateD2CircleItems(targetPrimitives: Map<string, TElementD2CircleJSONData>): void {
		for (let [key, primitiveItemValueData] of targetPrimitives) {
			const id: number = this._elementsMap.get(key)!
			this.updatePrimitiveItem(id, D2CircleDataGL.createArrayData(primitiveItemValueData))
		}
	}
	public deleteD2CircleItems(targetIds: Set<string>): void {
		const arrTargetIds: Array<string> = Array.from(targetIds)
		for (let i: number = 0; i < arrTargetIds.length; i++) {
			const primitiveId: number = this._elementsMap.get(arrTargetIds[i])!
			this.deletePrimitiveItem(primitiveId)
		}
	}

	public addD2ImageItems(targetPrimitives: Map<string, TElementD2ImageJSONData>): void {
		for (let [key, primitiveItemValueData] of targetPrimitives) {
			const id: number = this.addPrimitiveItem(D2ImageDataGL.createArrayData(primitiveItemValueData))
			this._elementsMap.set(key, id)
		}
	}
	public updateD2ImageItems(targetPrimitives: Map<string, TElementD2ImageJSONData>): void {
		for (let [key, primitiveItemValueData] of targetPrimitives) {
			const id: number = this._elementsMap.get(key)!
			this.updatePrimitiveItem(id, D2ImageDataGL.createArrayData(primitiveItemValueData))
		}
	}
	public deleteD2ImageItems(targetIds: Set<string>): void {
		const arrTargetIds: Array<string> = Array.from(targetIds)
		for (let i: number = 0; i < arrTargetIds.length; i++) {
			const primitiveId: number = this._elementsMap.get(arrTargetIds[i])!
			this.deletePrimitiveItem(primitiveId)
		}
	}

	public addD2LineItems(targetPrimitives: Map<string, TElementD2LineJSONData>): void {
		for (let [key, primitiveItemValueData] of targetPrimitives) {
			const id: number = this.addPrimitiveItem(D2LineDataGL.createArrayData(primitiveItemValueData))
			this._elementsMap.set(key, id)
		}
	}
	public updateD2LineItems(targetPrimitives: Map<string, TElementD2LineJSONData>): void {
		for (let [key, primitiveItemValueData] of targetPrimitives) {
			const id: number = this._elementsMap.get(key)!
			this.updatePrimitiveItem(id, D2LineDataGL.createArrayData(primitiveItemValueData))
		}
	}
	public deleteD2LineItems(targetIds: Set<string>): void {
		const arrTargetIds: Array<string> = Array.from(targetIds)
		for (let i: number = 0; i < arrTargetIds.length; i++) {
			const primitiveId: number = this._elementsMap.get(arrTargetIds[i])!
			this.deletePrimitiveItem(primitiveId)
		}
	}

	public addD2PointItems(targetPrimitives: Map<string, TElementD2PointJSONData>): void {
		for (let [key, primitiveItemValueData] of targetPrimitives) {
			const id: number = this.addPrimitiveItem(D2PointDataGL.createArrayData(primitiveItemValueData))
			this._elementsMap.set(key, id)
		}
	}
	public updateD2PointItems(targetPrimitives: Map<string, TElementD2PointJSONData>): void {
		for (let [key, primitiveItemValueData] of targetPrimitives) {
			const id: number = this._elementsMap.get(key)!
			this.updatePrimitiveItem(id, D2PointDataGL.createArrayData(primitiveItemValueData))
		}
	}
	public deleteD2PointItems(targetIds: Set<string>): void {
		const arrTargetIds: Array<string> = Array.from(targetIds)
		for (let i: number = 0; i < arrTargetIds.length; i++) {
			const primitiveId: number = this._elementsMap.get(arrTargetIds[i])!
			this.deletePrimitiveItem(primitiveId)
		}
	}

	public addD2TextItems(targetPrimitives: Map<string, TElementD2TextJSONData>): void {
		for (let [key, primitiveItemValueData] of targetPrimitives) {
			const id: number = this.addPrimitiveItem(D2TextDataGL.createArrayData(primitiveItemValueData))
			this._elementsMap.set(key, id)
		}
	}
	public updateD2TextItems(targetPrimitives: Map<string, TElementD2TextJSONData>): void {
		for (let [key, primitiveItemValueData] of targetPrimitives) {
			const id: number = this._elementsMap.get(key)!
			this.updatePrimitiveItem(id, D2TextDataGL.createArrayData(primitiveItemValueData))
		}
	}
	public deleteD2TextItems(targetIds: Set<string>): void {
		const arrTargetIds: Array<string> = Array.from(targetIds)
		for (let i: number = 0; i < arrTargetIds.length; i++) {
			const primitiveId: number = this._elementsMap.get(arrTargetIds[i])!
			this.deletePrimitiveItem(primitiveId)
		}
	}

	public render(): void {
		const viewMatrix4: Matrix4 = Camera.getInstance().getViewMatrix4(true)
		const viewMatrix4Data: Float32Array = new Float32Array(viewMatrix4.data)
		const zoomRatio: number = Camera.getInstance().getZoomRatio()
		const blocks: Array<PrimitiveBlock> = this._dataBuilder.getBlocks()
		for (let i: number = 0; i < blocks.length; i++) {
			blocks[i].ptsBuilder.update()
			this._programBuilder.render(PtType.D2_LINE, blocks[i].ptsBuilder.getDataBuffer(), 1, 0, viewMatrix4Data, zoomRatio)
		}
	}

	private addPrimitiveItem(pt: Float32Array): number {
		const primitiveId: number = this._dataBuilder.addPrimitiveItem(pt)
		return primitiveId
	}

	private updatePrimitiveItem(primitiveId: number, pt: Float32Array): void {
		const result: Float32Array = this._dataBuilder.updatePrimitiveItem(primitiveId, pt)
		console.warn(result)
	}

	private deletePrimitiveItem(primitiveId: number): void {
		const result: Float32Array = this._dataBuilder.deletePrimitiveItem(primitiveId)
		console.warn(result)
	}
}
