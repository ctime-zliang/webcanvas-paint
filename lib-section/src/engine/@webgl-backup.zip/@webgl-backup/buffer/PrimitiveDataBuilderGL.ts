import { BitmapIndex } from '../../common/utils/BitmapIndex'
import { CHUNK_SIZE, max32ArrayLen } from '../../config/CommonProfile'
import { MAX_PLANE_NUM } from '../PlaneGL'
import { PlaneIdMask, PtTools, PtType, PtTypeMask, PtTypeShift } from '../primitives/PrimitiveGL'
import { DataBufferGL } from './DataBufferGL'
import { BufferBuilderGL } from './BufferBuilderGL'
import { WebGL } from '../WebGL'
import { TypedArray32 } from '../../types/Common'

export interface PrimitiveBlock {
	isChanged: boolean
	readonly blockSize: number
	readonly ptOffset: number
	readonly idsBuilder: BufferBuilderGL<Float32Array>
	readonly startIndexsBuilder: BufferBuilderGL<Float32Array>
	readonly ptsBuilder: BufferBuilderGL<Float32Array>
	deledIndex: number
	deledNum: number
	deledStartIndex: number
}

const MAX_INDEXS_LEN: number = Math.floor(max32ArrayLen / 32 / 2) * 32

const MAX_DYNAMIC_PT_NUM: number = 4096

export class PrimitiveDataBuilderGL {
	private _webGL: WebGL
	private _maxDynamicPtNum: number
	private _ptIndexsArr: Array<Uint32Array>
	private _indexMap: BitmapIndex
	private _blocks: Array<PrimitiveBlock>
	private _blockIndex: number
	private _noBuildedPtNumsArr: Uint32Array
	private _needRenderStartIndexs: Map<PtType, Map<number, Set<number>>>
	constructor(webGL: WebGL, maxDynamicPtNum: number = MAX_DYNAMIC_PT_NUM) {
		this._webGL = webGL
		this._maxDynamicPtNum = maxDynamicPtNum
		this._noBuildedPtNumsArr = new Uint32Array(PtType.TYPE_NUM * MAX_PLANE_NUM)
		this._ptIndexsArr = []
		this._blocks = []
		this._blocks.push(this.initBlock())
		this._blockIndex = 0
		this.clear()
	}

	public getPrimitiveIndexsArray(): Array<Uint32Array> {
		return this._ptIndexsArr
	}

	public getNoBuildedPtNumsArr(): Uint32Array {
		return this._noBuildedPtNumsArr.slice(0, PtType.TYPE_NUM)
	}

	public getBlocks(): Array<PrimitiveBlock> {
		return this._blocks
	}

	public getNeedRenderStartIndexs(): Map<PtType, Map<number, Set<number>>> {
		return this._needRenderStartIndexs
	}

	public clear(): void {
		this.clearNoBuildedData()
		this._needRenderStartIndexs = new Map()
		this._needRenderStartIndexs.set(PtType.D2_ARC, new Map())
		this._needRenderStartIndexs.set(PtType.D2_CIRCLE, new Map())
		this._needRenderStartIndexs.set(PtType.D2_IMAGE, new Map())
		this._needRenderStartIndexs.set(PtType.D2_LINE, new Map())
		this._needRenderStartIndexs.set(PtType.D2_POINT, new Map())
		this._needRenderStartIndexs.set(PtType.D2_TEXT, new Map())
		this._ptIndexsArr.length = 0
		this._ptIndexsArr.push(new Uint32Array(CHUNK_SIZE))
		this._indexMap = new BitmapIndex(this._maxDynamicPtNum + 2)
		this._indexMap.markUsed(0)
	}

	public clearNoBuildedData(): void {
		for (let i: number = 0; i < this._blocks.length; i++) {
			const block: PrimitiveBlock = this._blocks[i]
			if (i === 0) {
				block.idsBuilder.clear()
				block.startIndexsBuilder.clear()
				block.ptsBuilder.clear()
				continue
			}
			block.idsBuilder.destroy()
			block.startIndexsBuilder.destroy()
			block.ptsBuilder.destroy()
		}
		this._blocks.length = 1
		this._blocks[0].deledIndex = Number.POSITIVE_INFINITY
		this._blocks[0].deledNum = 0
		this._blocks[0].idsBuilder.pushItem(-1)
		this._blocks[0].startIndexsBuilder.pushItem(-1)
		this._noBuildedPtNumsArr.fill(0)
	}

	public getNoBuildedPtNums(planeId: number): Uint32Array {
		return this._noBuildedPtNumsArr.slice(planeId * PtType.TYPE_NUM, (planeId + 1) * PtType.TYPE_NUM)
	}

	public isChange(): boolean {
		return this._blocks[0].startIndexsBuilder.isChange() || this._blocks[0].ptsBuilder.isChange() || this._blocks.length !== 1
	}

	public getPtNum(): number {
		return this._indexMap.getMarked() - 1
	}

	public getIdsLengthInBuf(): number {
		return this._blocks[0].startIndexsBuilder.getSize()
	}

	public getPtIndex(id: number): number {
		const ptIndex: number = this._ptIndexsArr[Math.floor(id / MAX_INDEXS_LEN)][id % MAX_INDEXS_LEN]
		if (ptIndex === 0 || ptIndex === undefined) {
			throw new Error('ptIndex === 0 || ptIndex === undefined')
		}
		return ptIndex
	}

	public addPrimitiveItem(pt: Float32Array, id: number = this._indexMap.findEmpty()): number {
		const needExtIndexMap: boolean = id === -1
		if (needExtIndexMap) {
			this._indexMap = this._indexMap.extendSize(this._indexMap.size * 2)
			id = this._indexMap.findEmpty()
		}
		this._indexMap.markUsed(id)
		if (needExtIndexMap && this.calcTypedArraysSum(this._ptIndexsArr) !== this._indexMap.size) {
			const lastPtIndexs: Uint32Array = this._ptIndexsArr[this._ptIndexsArr.length - 1]
			if (lastPtIndexs.length !== MAX_INDEXS_LEN) {
				const ptIndexs: Uint32Array = new Uint32Array(
					Math.min(MAX_INDEXS_LEN, this._indexMap.size - (this._ptIndexsArr.length - 1) * MAX_INDEXS_LEN)
				)
				ptIndexs.set(lastPtIndexs)
				this._ptIndexsArr[this._ptIndexsArr.length - 1] = ptIndexs
			}
			const end: number = Math.ceil(this._indexMap.size / MAX_INDEXS_LEN)
			for (let i: number = this._ptIndexsArr.length; i < end; i++) {
				this._ptIndexsArr.push(new Uint32Array(Math.min(MAX_INDEXS_LEN, this._indexMap.size - i * MAX_INDEXS_LEN)))
			}
		}
		this.insertPtItem(pt, id)
		return id
	}

	public updatePrimitiveItem(id: number, pt: Float32Array): Float32Array {
		const ptIndex: number = this.getPtIndex(id)
		const block: PrimitiveBlock = this._blocks[Math.floor(ptIndex / this._maxDynamicPtNum)]
		const index: number = ptIndex % this._maxDynamicPtNum
		const startIndex: number = block.startIndexsBuilder.getItemByIndex(index)
		const oldPt: Float32Array = block.ptsBuilder
			.getArr()
			.slice(startIndex, startIndex + PtTools.getPtLength(block.ptsBuilder.getItemByIndex(startIndex)))
		if (oldPt.length >= pt.length) {
			block.ptsBuilder.setArrByIndex(startIndex, pt)
		} else {
			this._noBuildedPtNumsArr[oldPt[0]]--
			block.startIndexsBuilder.setValueByIndex(index, -1)
			block.idsBuilder.setValueByIndex(index, 0)
			if (index < block.deledIndex) {
				block.deledIndex = index
				block.deledStartIndex = startIndex
			}
			block.deledNum++
			this.addPrimitiveItem(pt, id)
		}
		return oldPt
	}

	public deletePrimitiveItem(id: number): Float32Array {
		const ptIndex: number = this.getPtIndex(id)
		this._ptIndexsArr[Math.floor(id / MAX_INDEXS_LEN)][id % MAX_INDEXS_LEN] = 0
		this._indexMap.markRemove(id)
		const block: PrimitiveBlock = this._blocks[Math.floor(ptIndex / this._maxDynamicPtNum)]
		const index: number = ptIndex % this._maxDynamicPtNum
		const startIndex: number = block.startIndexsBuilder.getItemByIndex(index)
		const head: number = block.ptsBuilder.getItemByIndex(startIndex)
		this._noBuildedPtNumsArr[head]--
		block.startIndexsBuilder.setValueByIndex(index, -1)
		block.idsBuilder.setValueByIndex(index, 0)
		if (index < block.deledIndex) {
			block.deledIndex = index
			block.deledStartIndex = startIndex
		}
		block.deledNum++
		return block.ptsBuilder.getArr().slice(startIndex, startIndex + PtTools.getPtLength(block.ptsBuilder.getItemByIndex(startIndex)))
	}

	private insertPtItem(pt: Float32Array, id: number): void {
		if (this._blocks[this._blockIndex].idsBuilder.getSize() >= this._maxDynamicPtNum) {
			this._blocks[this._blockIndex].ptsBuilder.trim()
			let maxDeledNum: number = 0
			for (let i: number = 0; i < this._blocks.length; i++) {
				if (this._blocks[i].deledNum > maxDeledNum) {
					this._blockIndex = i
					maxDeledNum = this._blocks[i].deledNum
				}
			}
			if (maxDeledNum != 0) {
				this.updateBlock()
			} else {
				this._blocks.push(this.initBlock())
				this._blockIndex += 1
			}
		}
		const blockItem: PrimitiveBlock = this._blocks[this._blockIndex]
		this._ptIndexsArr[Math.floor(id / MAX_INDEXS_LEN)][id % MAX_INDEXS_LEN] = blockItem.idsBuilder.getSize() + blockItem.ptOffset
		blockItem.idsBuilder.pushItem(id)
		const startIndex: number = blockItem.ptsBuilder.getSize()
		blockItem.startIndexsBuilder.pushItem(startIndex)
		let tch1: Map<number, Set<number>> = this._needRenderStartIndexs.get(pt[0])!
		if (!tch1) {
			tch1 = new Map()
			this._needRenderStartIndexs.set(pt[0], tch1)
		}
		let tch2: Set<number> = tch1.get(this._blockIndex)!
		if (!tch2) {
			tch2 = new Set()
			tch1.set(this._blockIndex, tch2)
		}
		tch2.add(startIndex)
		blockItem.ptsBuilder.pushArr(pt)
		this._noBuildedPtNumsArr[pt[0]]++
	}

	private initBlock(): PrimitiveBlock {
		const arrSize1: number = this._maxDynamicPtNum + 2
		const arrSize2: number = this._maxDynamicPtNum * 30
		const blockItem: PrimitiveBlock = {
			isChanged: true,
			blockSize: this._maxDynamicPtNum,
			ptOffset: this._blocks.length * this._maxDynamicPtNum,
			idsBuilder: new BufferBuilderGL(
				Float32Array,
				new DataBufferGL(this._webGL, 1, 'ARRAY_BUFFER', this._webGL.gl.STATIC_DRAW),
				new Float32Array(arrSize1),
				0,
				arrSize1
			),
			startIndexsBuilder: new BufferBuilderGL(
				Float32Array,
				new DataBufferGL(this._webGL, 1, 'ARRAY_BUFFER', this._webGL.gl.STATIC_DRAW),
				new Float32Array(arrSize1),
				0,
				arrSize1
			),
			ptsBuilder: new BufferBuilderGL(
				Float32Array,
				new DataBufferGL(this._webGL, 1, 'ARRAY_BUFFER', this._webGL.gl.STATIC_DRAW),
				new Float32Array(arrSize2),
				0,
				arrSize2
			),
			deledIndex: Number.POSITIVE_INFINITY,
			deledNum: 0,
			deledStartIndex: 0,
		}
		return blockItem
	}

	private updateBlock(): void {
		const blockItem: PrimitiveBlock = this._blocks[this._blockIndex]
		if (blockItem.deledNum === 0) {
			return
		}
		const ids: Float32Array = blockItem.idsBuilder.getArr()
		const startIndexs: Float32Array = blockItem.startIndexsBuilder.getArr()
		const pts: Float32Array = blockItem.ptsBuilder.getArr()
		const end: number = ids.length
		let nextI: number = blockItem.deledIndex
		let nextStartIndex: number = blockItem.deledStartIndex
		for (let i: number = blockItem.deledIndex + 1; i < end; i++) {
			const startIndex = startIndexs[i]
			if (startIndex < 0) {
				continue
			}
			const id: number = ids[i]
			this._ptIndexsArr[Math.floor(id / MAX_INDEXS_LEN)][id % MAX_INDEXS_LEN] = nextI + blockItem.ptOffset
			ids[nextI] = id
			startIndexs[nextI++] = nextStartIndex
			const ptLength: number = PtTools.getPtLength(pts[startIndex])
			pts.set(pts.slice(startIndex, startIndex + ptLength), nextStartIndex)
			nextStartIndex += ptLength
		}
		blockItem.idsBuilder.markChange(blockItem.deledIndex, nextI)
		blockItem.startIndexsBuilder.markChange(blockItem.deledIndex, nextI)
		blockItem.ptsBuilder.markChange(blockItem.deledStartIndex, nextStartIndex)
		blockItem.deledIndex = Number.POSITIVE_INFINITY
		blockItem.deledNum = 0
		blockItem.idsBuilder.setLength(nextI)
		blockItem.startIndexsBuilder.setLength(nextI)
		blockItem.ptsBuilder.setLength(nextStartIndex)
	}

	private calcTypedArraysSum(typedArrays: Array<TypedArray32>): number {
		return typedArrays.reduce((prev, curr) => {
			return prev + curr.length
		}, 0)
	}
}
