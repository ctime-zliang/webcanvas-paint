import { BYTES32 } from '../../config/CommonProfile'
import { TypedArray32 } from '../../types/Common'
import { DataBufferGL } from './DataBufferGL'

interface ArrayConstructor<T extends TypedArray32> {
	new (length: number): T
	new (buffer: ArrayBuffer): T
}

export class BufferBuilderGL<T extends TypedArray32> {
	private _dataBuffer: DataBufferGL
	private _arrayConstructor: ArrayConstructor<T>
	private _maxLength: number
	private _arr: T
	private _upperIndex: number
	private _updateStart: number
	private _updateEnd: number
	constructor(
		arrayConstructor: ArrayConstructor<T>,
		dataBuffer: DataBufferGL,
		arr: T,
		size: number = 0,
		maxLength: number = Number.POSITIVE_INFINITY
	) {
		this._arrayConstructor = arrayConstructor
		this._dataBuffer = dataBuffer
		this._arr = arr
		this._maxLength = maxLength
		this._upperIndex = size
		this._updateStart = 0
		this._updateEnd = 0
	}

	public getItemByIndex(index: number): number {
		return this._arr[index]
	}

	public getDataBuffer(): DataBufferGL {
		return this._dataBuffer
	}

	public getArr(): T {
		return this._arr
	}

	public getSize(): number {
		return this._upperIndex
	}

	public setLength(len: number): void {
		if (Number.isFinite(this._updateEnd) && len < this._updateEnd) {
			if (len < this._updateStart) {
				this.markUpdated()
			} else {
				this._updateEnd = len
			}
		}
		this._upperIndex = len
	}

	public extArr(len: number): void {
		const rsize: number = 2 ** Math.ceil(Math.log2(len))
		const arr: T = new this._arrayConstructor(Math.min(rsize, rsize >= this._maxLength ? rsize : this._maxLength))
		arr.set(this._arr)
		this._arr = arr
	}

	public setValueByIndex(index: number, value: number): void {
		if (index >= this._upperIndex) {
			this._upperIndex = index + 1
			if (index >= this._arr.length) {
				this.extArr(index + 1)
			}
		}
		this._arr[index] = value
		this._updateStart = Math.min(this._updateStart, index)
		this._updateEnd = Math.max(this._updateEnd, index + 1)
	}

	public setArrByIndex(index: number, arr: T): void {
		const end: number = index + arr.length
		if (end > this._upperIndex) {
			this._upperIndex = end
			if (end > this._arr.length) {
				this.extArr(end)
			}
		}
		this._arr.set(arr, index)
		this._updateStart = Math.min(this._updateStart, index)
		this._updateEnd = Math.max(this._updateEnd, index + 1)
	}

	public pushItem(value: number): void {
		if (this._upperIndex === this._arr.length) {
			this.extArr(this._upperIndex + 1)
		}
		this._arr[this._upperIndex] = value
		this._upperIndex += 1
		this._updateStart = Math.min(this._updateStart, this._upperIndex - 1)
		this._updateEnd = Math.max(this._updateEnd, this._upperIndex)
	}

	public pushArr(arr: T): void {
		if (this._upperIndex + arr.length > this._arr.length) {
			this.extArr(this._upperIndex + arr.length)
		}
		this._arr.set(arr, this._upperIndex)
		this._upperIndex += arr.length
		this._updateStart = Math.min(this._updateStart, this._upperIndex - arr.length)
		this._updateEnd = Math.max(this._updateEnd, this._upperIndex)
	}

	public isChange(): boolean {
		return Number.isFinite(this._updateStart)
	}

	public trim(): void {
		const end: number = Math.max(this._upperIndex, this._maxLength)
		if (this._arr.length > end) {
			this._arr = this._arr.slice(0, end) as T
		}
	}

	public update(): DataBufferGL {
		const len: number = Math.max(this._upperIndex, 1)
		if (this._dataBuffer.getSize() > len) {
			this._dataBuffer.trim(len)
		} else {
			this._dataBuffer.extSize(len)
		}
		this._dataBuffer.submitData(this._arr.slice(0, this._upperIndex))
		this.markUpdated()
		return this._dataBuffer
	}

	public clear(): void {
		this._arr = new this._arrayConstructor(this._maxLength)
		this._upperIndex = 0
		this._dataBuffer.setSize(1)
		this._dataBuffer.submitData(this._arr.slice(0, this._upperIndex))
		if (this._dataBuffer.getSize() === 1) {
			this._dataBuffer.submitData(this._arr.slice(0, this._upperIndex))
		} else {
			this._dataBuffer.setSize(1)
		}
		this.markUpdated()
	}

	public destroy() {
		this._dataBuffer.destroy()
	}

	public markChange(start: number, end: number) {
		this._updateStart = Math.min(start, this._updateStart)
		this._updateEnd = Math.max(end, this._updateEnd)
		if (this._updateEnd > this._upperIndex) {
			throw new Error('update end out of range')
		}
	}

	private markUpdated(): void {
		this._updateStart = Number.POSITIVE_INFINITY
		this._updateEnd = Number.NEGATIVE_INFINITY
	}
}
