import { BYTES32 } from '../../../config/CommonProfile'
import { WebGL } from '../../WebGL'
import { DataBufferGL } from '../../buffer/DataBufferGL'
import { InstancedProgramGL } from '../../program/InstancedProgramGL'
import { D2CircleShaderGL } from './D2CircleShaderGL'
import { D2CircleDataGL } from './D2CircleDataGL'

const INIT_INDEX_DATA: Array<number> = [0, 1, 2]

export class D2CircleInstancedProgramGL extends InstancedProgramGL {
	private readonly _a_objPosition: number
	private readonly _a_param: number
	private readonly _a_strokeColor: number
	private readonly _a_fillColor: number
	private readonly _u_matrix: WebGLUniformLocation
	// private readonly _u_zoomRatio: WebGLUniformLocation
	constructor(webGL: WebGL) {
		super(webGL, D2CircleShaderGL.createVS(), D2CircleShaderGL.createFS(), new Float32Array(INIT_INDEX_DATA))
		this._a_objPosition = this.getWebGLAttributeLocation(`a_objPosition`)
		this._a_param = this.getWebGLAttributeLocation(`a_param`)
		this._a_strokeColor = this.getWebGLAttributeLocation(`a_strokeColor`)
		this._a_fillColor = this.getWebGLAttributeLocation(`a_fillColor`)
		this._u_matrix = this.getWebGLUniformLocation(`u_matrix`)
		// this._u_zoomRatio = this.getWebGLUniformLocation(`u_zoomRatio`)
	}

	public setEnableColor(): void {
		this.setEnableLoction(this.webGL.getWebGLAttributeLocation(this.webGLProgram, `a_strokeColor`))
		this.setEnableLoction(this.webGL.getWebGLAttributeLocation(this.webGLProgram, `a_fillColor`))
	}

	public setDisableColor(): void {
		this.setDisableLoction(this.webGL.getWebGLAttributeLocation(this.webGLProgram, `a_strokeColor`))
		this.setDisableLoction(this.webGL.getWebGLAttributeLocation(this.webGLProgram, `a_fillColor`))
	}

	public render(ptsBuf: DataBufferGL, ptNums: number, offset: number, viewMatrix4Data: Float32Array, zoomRatio: number): void {
		const gl: WebGL2RenderingContext = this.webGL.gl
		gl.useProgram(this.webGLProgram)
		this.setEnable()
		/* ... */
		gl.bindBuffer(ptsBuf.getWebglBufferType(), ptsBuf.getWebglBuffer())
		gl.vertexAttribPointer(this._a_objPosition, 4, gl.FLOAT, false, D2CircleDataGL.arrayDataSize * BYTES32, offset * BYTES32 + 1 * BYTES32)
		gl.vertexAttribPointer(this._a_param, 4, gl.FLOAT, false, D2CircleDataGL.arrayDataSize * BYTES32, offset * BYTES32 + 5 * BYTES32)
		gl.vertexAttribPointer(this._a_strokeColor, 4, gl.FLOAT, false, D2CircleDataGL.arrayDataSize * BYTES32, offset * BYTES32 + 9 * BYTES32)
		gl.vertexAttribPointer(this._a_fillColor, 4, gl.FLOAT, false, D2CircleDataGL.arrayDataSize * BYTES32, offset * BYTES32 + 13 * BYTES32)
		/* ... */
		gl.uniformMatrix4fv(this._u_matrix, false, viewMatrix4Data)
		// gl.uniform1f(this._u_zoomRatio, zoomRatio)
		/* ... */
		this.instancedArrays.drawArraysInstancedANGLE(gl.TRIANGLES, 0, INIT_INDEX_DATA.length, ptNums)
		this.setDisable()
	}
}
