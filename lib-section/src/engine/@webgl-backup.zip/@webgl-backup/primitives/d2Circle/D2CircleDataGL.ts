import { InsConfig } from '../../../common/InsConfig'
import { mm2px } from '../../../common/math/Calculation'
import { TColorRGBAJSON } from '../../../common/utils/Color'
import { ECanvas2DLineCap } from '../../../config/PrimitiveProfile'
import { TElementD2CircleJSONData } from '../../../types/Primitive'
import { PtType } from '../PrimitiveGL'

export class D2CircleDataGL {
	static arrayDataSize: number = 17
	static createArrayData(primitiveItemValueData: TElementD2CircleJSONData): Float32Array {
		const { alpha } = primitiveItemValueData
		const fillColorData: TColorRGBAJSON = primitiveItemValueData.fillColorData ? primitiveItemValueData.fillColorData : { r: 0, g: 0, b: 0, a: 0 }
		const typedArray: Array<number> = [
			PtType.D2_CIRCLE,
			/* ... */
			mm2px(primitiveItemValueData.centerPoint.x, InsConfig.DPI[0]),
			mm2px(primitiveItemValueData.centerPoint.y, InsConfig.DPI[1]),
			mm2px(primitiveItemValueData.centerPoint.z, InsConfig.DPI[0]),
			mm2px(primitiveItemValueData.radius, InsConfig.DPI[0]),
			/* ... */
			primitiveItemValueData.alpha,
			primitiveItemValueData.lineCap === ECanvas2DLineCap.ROUND ? 1.0 : 0.0,
			mm2px(primitiveItemValueData.strokeWidth, InsConfig.DPI[0]),
			primitiveItemValueData.isFill ? 1.0 : 0.0,
			/* ... */
			primitiveItemValueData.strokeColorData.r,
			primitiveItemValueData.strokeColorData.g,
			primitiveItemValueData.strokeColorData.b,
			primitiveItemValueData.strokeColorData.a * alpha,
			/* ... */
			fillColorData.r,
			fillColorData.g,
			fillColorData.b,
			fillColorData.a,
			/* ... */
			// primitiveItemValueData.isSolid ? 1 : 0,
			// mm2px(primitiveItemValueData.gapSize, InsConfig.DPI[0]),
			// mm2px(primitiveItemValueData.segSize, InsConfig.DPI[0]),
			// primitiveItemValueData.isFixedStrokeWidth ? 1 : 0,
		]
		return new Float32Array(typedArray)
	}
}
