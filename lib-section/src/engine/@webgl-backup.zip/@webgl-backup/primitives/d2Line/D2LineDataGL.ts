import { InsConfig } from '../../../common/InsConfig'
import { mm2px } from '../../../common/math/Calculation'
import { ECanvas2DLineCap } from '../../../config/PrimitiveProfile'
import { TElementD2LineJSONData } from '../../../types/Primitive'
import { PtType } from '../PrimitiveGL'

export class D2LineDataGL {
	static STRIDE: number = 19 * 4
	static createArrayData(primitiveItemValueData: TElementD2LineJSONData): Float32Array {
		const { alpha } = primitiveItemValueData
		const typedArray: Array<number> = [
			PtType.D2_LINE,
			/* ... */
			mm2px(primitiveItemValueData.startPoint.x, InsConfig.DPI[0]),
			mm2px(primitiveItemValueData.startPoint.y, InsConfig.DPI[1]),
			mm2px(primitiveItemValueData.startPoint.z, InsConfig.DPI[0]),
			mm2px(primitiveItemValueData.endPoint.x, InsConfig.DPI[0]),
			mm2px(primitiveItemValueData.endPoint.y, InsConfig.DPI[1]),
			mm2px(primitiveItemValueData.endPoint.z, InsConfig.DPI[0]),
			/* ... */
			primitiveItemValueData.alpha,
			primitiveItemValueData.lineCap === ECanvas2DLineCap.ROUND ? 1.0 : 0.0,
			mm2px(primitiveItemValueData.strokeWidth, InsConfig.DPI[0]),
			primitiveItemValueData.isSolid ? 1 : 0,
			/* ... */
			mm2px(primitiveItemValueData.segSize, InsConfig.DPI[0]),
			mm2px(primitiveItemValueData.gapSize, InsConfig.DPI[0]),
			primitiveItemValueData.isFixedStrokeWidth ? 1 : 0,
			0,
			/* ... */
			primitiveItemValueData.strokeColorData.r,
			primitiveItemValueData.strokeColorData.g,
			primitiveItemValueData.strokeColorData.b,
			primitiveItemValueData.strokeColorData.a * alpha,
		]
		return new Float32Array(typedArray)
	}
}
