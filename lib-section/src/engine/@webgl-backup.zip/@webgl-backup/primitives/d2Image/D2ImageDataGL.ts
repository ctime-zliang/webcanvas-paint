import { InsConfig } from '../../../common/InsConfig'
import { mm2px } from '../../../common/math/Calculation'
import { TElementD2ImageJSONData } from '../../../types/Primitive'
import { PtType } from '../PrimitiveGL'

export class D2ImageDataGL {
	static arrayDataSize: number = 10
	static createArrayData(primitiveItemValueData: TElementD2ImageJSONData): Float32Array {
		const { alpha } = primitiveItemValueData
		const lUpX: number = primitiveItemValueData.startPoint.x
		const lUpY: number = primitiveItemValueData.startPoint.y
		const lUpZ: number = primitiveItemValueData.startPoint.z
		const lDownX: number = primitiveItemValueData.startPoint.x
		const lDownY: number = primitiveItemValueData.startPoint.y - primitiveItemValueData.height
		/* ... */
		const rUpX: number = primitiveItemValueData.startPoint.x + primitiveItemValueData.width
		const rUpY: number = primitiveItemValueData.startPoint.y
		const rUpZ: number = primitiveItemValueData.startPoint.z
		const rDownX: number = primitiveItemValueData.startPoint.x + primitiveItemValueData.width
		const rDownY: number = primitiveItemValueData.startPoint.y - primitiveItemValueData.height
		const typedArray: Array<number> = [
			PtType.D2_IMAGE,
			/* ... */
			mm2px(lUpX, InsConfig.DPI[0]),
			mm2px(lUpY, InsConfig.DPI[1]),
			mm2px(lDownX, InsConfig.DPI[0]),
			mm2px(lDownY, InsConfig.DPI[1]),
			/* ... */
			mm2px(rUpX, InsConfig.DPI[0]),
			mm2px(rUpY, InsConfig.DPI[1]),
			mm2px(rDownX, InsConfig.DPI[0]),
			mm2px(rDownY, InsConfig.DPI[1]),
			/* ... */
			primitiveItemValueData.alpha,
		]
		return new Float32Array(typedArray)
	}
}
