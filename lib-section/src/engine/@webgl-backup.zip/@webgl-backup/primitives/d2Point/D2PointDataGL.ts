import { InsConfig } from '../../../common/InsConfig'
import { mm2px } from '../../../common/math/Calculation'
import { ED2PointShape } from '../../../config/PrimitiveProfile'
import { TElementD2PointJSONData } from '../../../types/Primitive'
import { PtType } from '../PrimitiveGL'

export class D2PointDataGL {
	static arrayDataSize: number = 13
	static createArrayData(primitiveItemValueData: TElementD2PointJSONData): Float32Array {
		const { alpha, isEnableScale, shape } = primitiveItemValueData
		const typedArray: Array<number> = [
			PtType.D2_POINT,
			/* ... */
			mm2px(primitiveItemValueData.centerPoint.x, InsConfig.DPI[0]),
			mm2px(primitiveItemValueData.centerPoint.y, InsConfig.DPI[1]),
			mm2px(primitiveItemValueData.centerPoint.z, InsConfig.DPI[0]),
			mm2px(primitiveItemValueData.size, InsConfig.DPI[0]),
			/* ... */
			primitiveItemValueData.alpha,
			isEnableScale ? 1.0 : 0.0,
			shape === ED2PointShape.DOT ? 1.0 : 2.0,
			0.0,
			/* ... */
			primitiveItemValueData.strokeColorData.r,
			primitiveItemValueData.strokeColorData.g,
			primitiveItemValueData.strokeColorData.b,
			primitiveItemValueData.strokeColorData.a * alpha,
		]
		return new Float32Array(typedArray)
	}
}
