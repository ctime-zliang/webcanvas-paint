import { InsConfig } from '../../../common/InsConfig'
import { mm2px } from '../../../common/math/Calculation'
import { TElementD2TextJSONData } from '../../../types/Primitive'
import { PtType } from '../PrimitiveGL'

export class D2TextDataGL {
	static arrayDataSize: number = 13
	static createArrayData(primitiveItemValueData: TElementD2TextJSONData): Float32Array {
		const { alpha } = primitiveItemValueData
		const typedArray: Array<number> = [
			PtType.D2_TEXT,
			/* ... */
			mm2px(primitiveItemValueData.startPoint.x, InsConfig.DPI[0]),
			mm2px(primitiveItemValueData.startPoint.y, InsConfig.DPI[1]),
			mm2px(primitiveItemValueData.startPoint.z, InsConfig.DPI[0]),
			0.0,
			/* ... */
			primitiveItemValueData.alpha,
			primitiveItemValueData.fontSize,
			0.0,
			0.0,
			/* ... */
			primitiveItemValueData.strokeColorData.r,
			primitiveItemValueData.strokeColorData.g,
			primitiveItemValueData.strokeColorData.b,
			primitiveItemValueData.strokeColorData.a * alpha,
		]
		return new Float32Array(typedArray)
	}
	static translatePositions(sourcePositions: Array<number>): Array<number> {
		const allPositions: Array<number> = []
		for (let i: number = 0; i < sourcePositions.length; i++) {
			allPositions.push(mm2px(sourcePositions[i], InsConfig.DPI[0]))
		}
		return allPositions
	}
}
