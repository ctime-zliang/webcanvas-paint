import { GPUBufferUsageFlags, GPUCommandEncoder, GPUDevice, GPUSize64, GPUTextureFormat } from '../config/Types'
import { BYTES32 } from '../core/utils'
import { TypedArray32 } from './BufferBuilder'
import { DynamicArrayBuffer } from './DynamicArrayBuffer'

export class WebGPU {
	public gl: WebGL2RenderingContext
	public device: GPUDevice
	public presentationFormat: GPUTextureFormat
	public textureCompression: 'bc' | 'astc' | 's3tc' | 'etc2' | 'none'
	public tempBufIndex: any
	public bufferSize: number
	constructor(gl: WebGL2RenderingContext, device: GPUDevice) {
		this.gl = gl
		this.device = device
		this.bufferSize = 0
	}

	public createWebGPUBuffer(bufferSize32: number, gpuUsage: GPUBufferUsageFlags, mappedAtCreation: boolean, label: string) {
		this.bufferSize += bufferSize32
		return this.device.createBuffer({
			size: bufferSize32 * BYTES32,
			gpuUsage,
			mappedAtCreation,
			label,
		})
	}

	public createWebGLArrayBufferBySize(bufferSize32: number, glUsage: GLenum) {
		this.bufferSize += bufferSize32
		const webGLBuffer: WebGLBuffer = this.gl.createBuffer()!
		this.gl.bindBuffer(this.gl.ARRAY_BUFFER, webGLBuffer)
		this.gl.bufferData(this.gl.ARRAY_BUFFER, new Float32Array(bufferSize32), glUsage)
		this.gl.bindBuffer(this.gl.ARRAY_BUFFER, null)
		return webGLBuffer
	}

	public createWebGLArrayBufferByBuffer(data: ArrayBuffer | TypedArray32, glUsage: GLenum) {
		const webGLBuffer: WebGLBuffer = this.gl.createBuffer()!
		this.gl.bindBuffer(this.gl.ARRAY_BUFFER, webGLBuffer)
		this.gl.bufferData(this.gl.ARRAY_BUFFER, data, glUsage)
		this.gl.bindBuffer(this.gl.ARRAY_BUFFER, null)
		return webGLBuffer
	}

	public createWebGLElementBufferBySize(bufferSize32: number, glUsage: GLenum) {
		this.bufferSize += bufferSize32
		const webGLBuffer: WebGLBuffer = this.gl.createBuffer()!
		this.gl.bindBuffer(this.gl.ELEMENT_ARRAY_BUFFER, webGLBuffer)
		this.gl.bufferData(this.gl.ELEMENT_ARRAY_BUFFER, new Float32Array(bufferSize32), glUsage)
		this.gl.bindBuffer(this.gl.ELEMENT_ARRAY_BUFFER, null)
		return webGLBuffer
	}

	public createWebGLElementBufferByBuffer(data: ArrayBuffer | TypedArray32, glUsage: GLenum) {
		const webGLBuffer: WebGLBuffer = this.gl.createBuffer()!
		this.gl.bindBuffer(this.gl.ELEMENT_ARRAY_BUFFER, webGLBuffer)
		this.gl.bufferData(this.gl.ELEMENT_ARRAY_BUFFER, data, glUsage)
		this.gl.bindBuffer(this.gl.ELEMENT_ARRAY_BUFFER, null)
		return webGLBuffer
	}

	// public createDynamicBuffer(size32: number, gpuUsage: GPUBufferUsageFlags, label: string): DynamicBuffer {
	// 	return new DynamicBuffer(this, size32, gpuUsage, label)
	// }

	public copyBufferToBuffer(
		sourceBuffer: DynamicArrayBuffer,
		sourceBufferOffset32: GPUSize64,
		destinationBuffer: DynamicArrayBuffer,
		destinationBufferOffset32: GPUSize64,
		size32: GPUSize64,
		commandEncoder?: GPUCommandEncoder
	) {}

	public writeBuffer(
		buffer: DynamicArrayBuffer,
		offset32: GPUSize64,
		data: ArrayBuffer | TypedArray32,
		dataOffset32: GPUSize64 = 0,
		size32?: GPUSize64
	) {}

	public readBuffer(buffer: DynamicArrayBuffer, start32: number, end32: number = buffer.getSize()): ArrayBuffer {
		return null!
	}
}
