import { GPUBufferUsageFlags } from '../config/Types'
import { CHUNK_SIZE } from '../core/utils'
import { DynamicArrayBuffer } from './DynamicArrayBuffer'
import { WebGPU } from './WebGPU'

export type TypedArray32 = Int32Array | Uint32Array | Float32Array

interface ArrayConstructor<T extends TypedArray32> {
	new (length: number): T
	new (buffer: ArrayBuffer): T
}

export class BufferBuilder<T extends TypedArray32> {
	static create<T extends TypedArray32>(arrayConstructor: ArrayConstructor<T>, gpu: WebGPU, maxLength = Number.POSITIVE_INFINITY) {
		return new BufferBuilder(arrayConstructor, new DynamicArrayBuffer(gpu, 1), new arrayConstructor(CHUNK_SIZE), 0, maxLength)
	}

	static async createWithBuf<T extends TypedArray32>(
		arrayConstructor: ArrayConstructor<T>,
		buf: DynamicArrayBuffer,
		maxLength = Number.POSITIVE_INFINITY
	) {
		return new BufferBuilder(arrayConstructor, buf, new arrayConstructor(await buf.read()), buf.getSize(), maxLength)
	}

	public buf: DynamicArrayBuffer
	public arrayConstructor: ArrayConstructor<T>
	public maxLength: number
	public arr: T
	public length: number
	public updateStart: number
	public updateEnd: number
	constructor(arrayConstructor: ArrayConstructor<T>, buf: DynamicArrayBuffer, arr: T, length: number, maxLength: number) {
		this.arrayConstructor = arrayConstructor
		this.buf = buf
		this.arr = arr
		this.maxLength = maxLength
		this.length = length
	}

	public get(i) {
		return this.arr[i]
	}

	public getArr() {
		return this.arr
	}

	public getLength() {
		return this.length
	}

	public setLength(len: number) {
		if (Number.isFinite(this.updateEnd) && len < this.updateEnd) {
			if (len < this.updateStart) {
				this.markUpdated()
			} else {
				this.updateEnd = len
			}
		}
		this.length = len
	}

	public extArr(minLen: number) {
		const arr = new this.arrayConstructor(Math.min(2 ** Math.ceil(Math.log2(minLen)), this.maxLength))
		arr.set(this.arr)
		this.arr = arr
	}

	public set(i, value) {
		if (i >= this.length) {
			this.length = i + 1
			if (i >= this.arr.length) {
				this.extArr(i + 1)
			}
		}
		this.arr[i] = value
		this.updateStart = Math.min(this.updateStart, i)
		this.updateEnd = Math.max(this.updateEnd, i + 1)
	}

	public setArr(arr: T, i: number) {
		const end = i + arr.length
		if (end > this.length) {
			this.length = end
			if (end > this.arr.length) {
				this.extArr(end)
			}
		}
		this.arr.set(arr, i)
		this.updateStart = Math.min(this.updateStart, i)
		this.updateEnd = Math.max(this.updateEnd, i + 1)
	}

	public push(value) {
		if (this.length === this.arr.length) {
			this.extArr(this.length + 1)
		}
		this.arr[this.length] = value
		this.updateStart = Math.min(this.updateStart, this.length)
		this.updateEnd = Math.max(this.updateEnd, ++this.length)
	}

	public pushArr(arr: T) {
		if (this.length + arr.length > this.arr.length) {
			this.extArr(this.length + arr.length)
		}
		this.arr.set(arr, this.length)
		this.updateStart = Math.min(this.updateStart, this.length)
		this.updateEnd = Math.max(this.updateEnd, (this.length += arr.length))
	}

	public isChange() {
		return Number.isFinite(this.updateStart)
	}

	public markUpdated() {
		this.updateStart = Number.POSITIVE_INFINITY
		this.updateEnd = Number.NEGATIVE_INFINITY
	}

	public trim() {
		const end = Math.max(this.length, CHUNK_SIZE)
		if (this.arr.length > end) {
			this.arr = this.arr.slice(0, end) as T
		}
	}

	public update() {
		const len = Math.max(this.length, 1)
		if (this.buf.getSize() > len) {
			this.buf.trim(len)
		} else {
			this.buf.extSize(len)
		}
		this.buf.write(this.updateStart, this.arr, this.updateStart, this.updateEnd - this.updateStart)
		this.markUpdated()
		return this.buf
	}

	public markChange(start: number, end: number) {
		this.updateStart = Math.min(start, this.updateStart)
		this.updateEnd = Math.max(end, this.updateEnd)
		if (this.updateEnd > this.length) {
			throw new Error('update end out of range')
		}
	}

	public clear() {
		this.arr = new this.arrayConstructor(CHUNK_SIZE)
		if (this.buf.getSize() === 1) {
			this.buf.write(0, this.arr)
		} else {
			this.buf.setSize(1)
		}
		this.length = 0
		this.markUpdated()
	}

	public destroy() {
		this.buf.destroy()
	}
}
