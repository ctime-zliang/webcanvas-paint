import { GPUBuffer, GPUBufferUsageFlags, GPUSize64 } from '../config/Types'
import { BYTES32 } from '../core/utils'
import { TypedArray32 } from './BufferBuilder'
import { WebGPU } from './WebGPU'

export class DynamicArrayBuffer {
	public gpu: WebGPU
	public gpuBuffer: GPUBuffer
	public webglBuffer: WebGLBuffer
	public glUsage: GLenum
	constructor(gpu: WebGPU, size32: number) {
		this.gpu = gpu
		this.glUsage = this.gpu.gl.STATIC_DRAW
		// this.gpuBuffer = this.gpu.createWebGPUBuffer(size32, gpuUsage, false, label)
		this.webglBuffer = this.gpu.createWebGLArrayBufferBySize(size32, this.glUsage)
	}

	public getSize() {
		// return this.gpuBuffer.size / BYTES32
		return this.gpu.bufferSize
	}

	// public getBuffer() {
	// 	return this.gpuBuffer
	// }

	public read(start32 = 0, end32 = this.getSize()) {
		return this.gpu.readBuffer(this, start32, end32)
	}

	public destroy() {
		this.gpu.bufferSize -= this.getSize()
		this.gpuBuffer.destroy()
	}

	public setSize(size32: number) {
		if (size32 === this.getSize()) {
			return
		}
		this.setBuffer(this.gpu.createWebGLArrayBufferBySize(size32, this.glUsage))
	}

	public extSize(size32: number) {
		if (size32 === this.getSize()) {
			return
		}
		const buffer = new DynamicArrayBuffer(this.gpu, size32)
		this.gpu.copyBufferToBuffer(this, 0, buffer, 0, this.getSize())
		this.setBuffer(buffer.webglBuffer)
	}

	public trim(size32: number) {
		if (size32 === this.getSize()) {
			return
		}
		if (size32 > this.getSize()) {
			throw new Error('ArrayBuffer: trim size must less than buffer size')
		}
		const buffer = new DynamicArrayBuffer(this.gpu, size32)
		this.gpu.copyBufferToBuffer(this, 0, buffer, 0, size32)
		this.setBuffer(buffer.webglBuffer)
	}

	public setBuffer(buf: GPUBuffer) {
		this.gpu.bufferSize -= this.getSize()
		// this.gpuBuffer.destroy()
		this.gpu.gl.deleteBuffer(this.webglBuffer)
		// this.gpuBuffer = buf
		this.webglBuffer = buf
	}

	// public molt(newSize: number) {
	// 	const buf = new DynamicArrayBuffer(this.gpu, 0, this.gpuBuffer.gpuUsage, this.gpuBuffer.label)
	// 	buf.setBuffer(this.gpuBuffer)
	// 	this.gpuBuffer = this.gpu.createWebGPUBuffer(newSize, this.gpuBuffer.gpuUsage, false, this.gpuBuffer.label)
	// 	return buf
	// }

	// public setDynamicBuffer(buf: DynamicArrayBuffer) {
	// 	this.setBuffer(buf.gpuBuffer)
	// }

	public write(offset32: GPUSize64, data: ArrayBuffer | TypedArray32, dataOffset332: GPUSize64 = 0, size32?: GPUSize64) {
		this.gpu.writeBuffer(this, offset32, data, dataOffset332, size32)
	}
}
