export const copyNumX = 1
export const copyNumY = 1
export const copyOffsetX = 0
export const copyOffsetY = 0

export const BYTES32 = 4
export const max32ArrayLen = 2 ** 30 / BYTES32
export const max64ArrayLen = max32ArrayLen / 2

export const CHUNK_SIZE = 4096
