import { BitmapIndex } from '../../common/utils/BitmapIndex'
import { BufferBuilder } from '../baseClass/BufferBuilder'
import { DynamicArrayBuffer } from '../baseClass/DynamicArrayBuffer'
import { WebGPU } from '../baseClass/WebGPU'
import { PlaneIdMask, PtTools, PtType, PtTypeMask, PtTypeShift } from '../primitives/PrimitiveGPU'
import { MAX_PLANE_NUM } from './SceneGPU'
import { CHUNK_SIZE, max32ArrayLen } from './utils'

interface PtBlock {
	ptOffset: number
	idsBuilder: BufferBuilder<Uint32Array>
	startIndexsBuilder: BufferBuilder<Int32Array>
	ptsBuilder: BufferBuilder<Float32Array>
	deledIndex: number
	deledNum: number
	deledStartIndex: number
}

interface PtsInfo {
	indexInfoBuffer: ArrayBuffer
	ptsBuf: ArrayBuffer
	ptNum: number
}

const MAX_INDEXS_LEN: number = Math.floor(max32ArrayLen / 32 / 2) * 32

export class PtBufferBuilder {
	public gpu: WebGPU
	public maxDynamicPtNum: number
	public ptIndexsArr: Array<Uint32Array>
	public indexMap: BitmapIndex
	public blocks: Array<PtBlock>
	public block: PtBlock
	public noBuildedPtNumsArr: Uint32Array
	constructor(gpu: WebGPU, maxDynamicPtNum: number = Number.MAX_SAFE_INTEGER) {
		this.gpu = gpu
		this.maxDynamicPtNum = maxDynamicPtNum
		this.noBuildedPtNumsArr = new Uint32Array(PtType.TYPE_NUM * MAX_PLANE_NUM)
		this.ptIndexsArr = []
		this.blocks = []
		this.initBlock()
		this.clear()
	}

	public initBlock() {
		this.block = {
			ptOffset: this.blocks.length * this.maxDynamicPtNum,
			idsBuilder: BufferBuilder.create(Uint32Array, this.gpu, this.maxDynamicPtNum),
			startIndexsBuilder: BufferBuilder.create(Int32Array, this.gpu, this.maxDynamicPtNum),
			ptsBuilder: BufferBuilder.create(Float32Array, this.gpu, this.maxDynamicPtNum * 3),
			deledIndex: Number.POSITIVE_INFINITY,
			deledNum: 0,
			deledStartIndex: 0,
		}
		this.blocks.push(this.block)
	}

	public clearNoBuildedData() {
		for (let i: number = 0; i < this.blocks.length; i++) {
			const block: PtBlock = this.blocks[i]
			if (i === 0) {
				block.idsBuilder.clear()
				block.startIndexsBuilder.clear()
				block.ptsBuilder.clear()
				continue
			}
			block.idsBuilder.destroy()
			block.startIndexsBuilder.destroy()
			block.ptsBuilder.destroy()
		}
		this.blocks.length = 1
		this.block = this.blocks[0]
		this.block.deledIndex = Number.POSITIVE_INFINITY
		this.block.deledNum = 0
		this.block.idsBuilder.push(0)
		this.block.startIndexsBuilder.push(-1)
		this.noBuildedPtNumsArr.fill(0)
	}

	public getNoBuildedPtNums(planeId: number) {
		return this.noBuildedPtNumsArr.slice(planeId * PtType.TYPE_NUM, (planeId + 1) * PtType.TYPE_NUM)
	}

	public clear() {
		this.clearNoBuildedData()
		this.ptIndexsArr.length = 0
		this.ptIndexsArr.push(new Uint32Array(CHUNK_SIZE))
		this.indexMap = new BitmapIndex(CHUNK_SIZE)
		this.indexMap.markUsed(0)
	}

	public isChange() {
		return this.blocks[0].startIndexsBuilder.isChange() || this.blocks[0].ptsBuilder.isChange() || this.blocks.length !== 1
	}

	public update() {
		if (this.blocks.length !== 1) {
			throw new Error('this.blocks.length !== 1')
		}
		return {
			startIndexsBuf: this.block.startIndexsBuilder.update(),
			ptsBuf: this.block.ptsBuilder.update(),
		}
	}

	public updateBlock() {
		if (this.block.deledNum === 0) {
			return
		}
		const ids = this.block.idsBuilder.getArr()
		const startIndexs = this.block.startIndexsBuilder.getArr()
		const pts = this.block.ptsBuilder.getArr()
		const end = ids.length
		let nextI = this.block.deledIndex
		let nextStartIndex = this.block.deledStartIndex
		for (let i = this.block.deledIndex + 1; i < end; i++) {
			const startIndex = startIndexs[i]
			if (startIndex < 0) {
				continue
			}
			const id = ids[i]
			this.ptIndexsArr[Math.floor(id / MAX_INDEXS_LEN)][id % MAX_INDEXS_LEN] = nextI + this.block.ptOffset
			ids[nextI] = id
			startIndexs[nextI++] = nextStartIndex
			const ptLength = PtTools.getPtLength(pts[startIndex])
			pts.set(pts.slice(startIndex, startIndex + ptLength), nextStartIndex)
			nextStartIndex += ptLength
		}
		this.block.idsBuilder.markChange(this.block.deledIndex, nextI)
		this.block.startIndexsBuilder.markChange(this.block.deledIndex, nextI)
		this.block.ptsBuilder.markChange(this.block.deledStartIndex, nextStartIndex)
		this.block.deledIndex = Number.POSITIVE_INFINITY
		this.block.deledNum = 0
		this.block.idsBuilder.setLength(nextI)
		this.block.startIndexsBuilder.setLength(nextI)
		this.block.ptsBuilder.setLength(nextStartIndex)
	}

	public addPt0(pt: Float32Array, id: number) {
		if (this.block.idsBuilder.getLength() === this.maxDynamicPtNum) {
			this.block.ptsBuilder.trim()
			let maxDeledNum = 0
			for (let block of this.blocks) {
				if (block.deledNum > maxDeledNum) {
					this.block = block
					maxDeledNum = block.deledNum
				}
			}
			if (maxDeledNum != 0) {
				this.updateBlock()
			} else {
				this.initBlock()
			}
		}
		this.ptIndexsArr[Math.floor(id / MAX_INDEXS_LEN)][id % MAX_INDEXS_LEN] = this.block.idsBuilder.getLength() + this.block.ptOffset
		this.block.idsBuilder.push(id)
		this.block.startIndexsBuilder.push(this.block.ptsBuilder.getLength())
		this.block.ptsBuilder.pushArr(pt)
		this.noBuildedPtNumsArr[(pt[0] & PlaneIdMask) * PtType.TYPE_NUM + ((pt[0] & PtTypeMask) >> PtTypeShift)]++
	}

	public addPt(pt: Float32Array, id = this.indexMap.findEmpty()) {
		const needExtIndexMap = id === -1
		if (needExtIndexMap) {
			this.indexMap = this.indexMap.extendSize(this.indexMap.size * 2)
			id = this.indexMap.findEmpty()
		}
		this.indexMap.markUsed(id)
		if (needExtIndexMap && this.ptIndexsArr.reduce((prev, curr) => prev + curr.length, 0) !== this.indexMap.size) {
			const lastPtIndexs = this.ptIndexsArr[this.ptIndexsArr.length - 1]
			if (lastPtIndexs.length !== MAX_INDEXS_LEN) {
				const ptIndexs = new Uint32Array(Math.min(MAX_INDEXS_LEN, this.indexMap.size - (this.ptIndexsArr.length - 1) * MAX_INDEXS_LEN))
				ptIndexs.set(lastPtIndexs)
				this.ptIndexsArr[this.ptIndexsArr.length - 1] = ptIndexs
			}
			const end = Math.ceil(this.indexMap.size / MAX_INDEXS_LEN)
			for (let i = this.ptIndexsArr.length; i < end; i++) {
				this.ptIndexsArr.push(new Uint32Array(Math.min(MAX_INDEXS_LEN, this.indexMap.size - i * MAX_INDEXS_LEN)))
			}
		}
		this.addPt0(pt, id)
		return id
	}

	public getPtIndex(id: number) {
		const ptIndex = this.ptIndexsArr[Math.floor(id / MAX_INDEXS_LEN)][id % MAX_INDEXS_LEN]
		if (ptIndex === 0 || ptIndex === undefined) {
			throw new Error('ptIndex === 0 || ptIndex === undefined')
		}
		return ptIndex
	}

	public removePt(id: number) {
		const ptIndex = this.getPtIndex(id)
		this.ptIndexsArr[Math.floor(id / MAX_INDEXS_LEN)][id % MAX_INDEXS_LEN] = 0
		this.indexMap.markRemove(id)
		const block = this.blocks[Math.floor(ptIndex / this.maxDynamicPtNum)]
		const index = ptIndex % this.maxDynamicPtNum
		const startIndex = block.startIndexsBuilder.get(index)
		const head = block.ptsBuilder.get(startIndex)
		this.noBuildedPtNumsArr[(head & PlaneIdMask) * PtType.TYPE_NUM + ((head & PlaneIdMask) >> PtTypeShift)]--
		block.startIndexsBuilder.set(index, -1)
		block.idsBuilder.set(index, 0)
		if (index < block.deledIndex) {
			block.deledIndex = index
			block.deledStartIndex = startIndex
		}
		block.deledNum++
		return block.ptsBuilder.getArr().slice(startIndex, startIndex + PtTools.getPtLength(block.ptsBuilder.get(startIndex)))
	}

	public updatePt(id: number, pt: Float32Array) {
		const ptIndex = this.getPtIndex(id)
		const block = this.blocks[Math.floor(ptIndex / this.maxDynamicPtNum)]
		const index = ptIndex % this.maxDynamicPtNum
		const startIndex = block.startIndexsBuilder.get(index)
		const oldPt = block.ptsBuilder.getArr().slice(startIndex, startIndex + PtTools.getPtLength(block.ptsBuilder.get(startIndex)))
		if (oldPt.length >= pt.length) {
			block.ptsBuilder.setArr(pt, startIndex)
		} else {
			const head = oldPt[0]
			this.noBuildedPtNumsArr[(head & PlaneIdMask) * PtType.TYPE_NUM + ((head & PtTypeMask) >> PtTypeShift)]--
			block.startIndexsBuilder.set(index, -1)
			block.idsBuilder.set(index, 0)
			if (index < block.deledIndex) {
				block.deledIndex = index
				block.deledStartIndex = startIndex
			}
			block.deledNum++
			this.addPt0(pt, id)
		}
		return oldPt
	}

	public getPtNum() {
		return this.indexMap.getMarked() - 1
	}

	public getIdsLengthInBuf() {
		return this.blocks[0].startIndexsBuilder.getLength()
	}

	public async build() {
		if (this.blocks.length === 1) {
			this.update()
			return this.noBuildedPtNumsArr
		}
		let panelNum: number = undefined!
		for (let i: number = this.noBuildedPtNumsArr.length - 1; i >= 0; i--) {
			if (this.noBuildedPtNumsArr[i] !== 0) {
				panelNum = Math.ceil(i / PtType.TYPE_NUM)
				break
			}
		}
		const ptNums = new Uint32Array(panelNum)
		for (let i = 0; i < panelNum; i++) {
			const end = (i + 1) * PtType.TYPE_NUM
			let num = 0
			for (let j = i * PtType.TYPE_NUM; j < end; j++) {
				num += this.noBuildedPtNumsArr[j]
			}
			ptNums[i] = num
		}
		const block = this.blocks[0]
		const a = block.idsBuilder.update()
		const b = block.startIndexsBuilder.update()
		const c = block.ptsBuilder.update()
		block.idsBuilder.clear()
		block.startIndexsBuilder.clear()
		block.ptsBuilder.clear()
		for (let i = 1; i < this.blocks.length; i++) {
			const ai = this.blocks[i].idsBuilder.update()
			const bi = this.blocks[i].startIndexsBuilder.update()
			const ci = this.blocks[i].ptsBuilder.update()
			this.blocks[i].idsBuilder.destroy()
			this.blocks[i].startIndexsBuilder.destroy()
			this.blocks[i].ptsBuilder.destroy()
			this.blocks[i] = undefined!
		}
		this.blocks = this.blocks.filter(item => {
			return !!item
		})
		this.clearNoBuildedData()
		const ptIndexsBuffer = new DynamicArrayBuffer(
			this.gpu,
			this.ptIndexsArr.reduce((prev, curr) => prev + curr.length, 0)
		)
		this.ptIndexsArr.forEach((v, i) => {
			ptIndexsBuffer.write(i * MAX_INDEXS_LEN, v)
		})
		ptIndexsBuffer.destroy()
	}
}
