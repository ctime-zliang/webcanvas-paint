import { BitmapIndex } from '../../common/utils/BitmapIndex'
import { WebGPU } from '../baseClass/WebGPU'
import { PlaneGPU } from './PlaneGPU'

export const MAX_PLANE_NUM = 1024

export class SceneGPU {
	public planeIdMap: BitmapIndex
	public gpu: WebGPU
	public planes: Array<PlaneGPU>
	constructor(gpu: WebGPU) {
		this.gpu = gpu
		this.planeIdMap = new BitmapIndex(MAX_PLANE_NUM)
		this.planeIdMap.markUsed(0)
		this.planes = []
	}

	public getPlaneId() {
		const id: number = this.planeIdMap.findEmpty()
		this.planeIdMap.markUsed(id)
		return id
	}

	public async render() {
		await this.render0()
	}

	public async render0() {
		await this.renderPlanes()
	}

	public async renderPlanes() {
		for (let i = 0; i < this.planes.length; i++) {
			await this.planes[i].render()
		}
	}
}
