import { TElementD2ArcJSONData, TElementD2CircleJSONData, TElementD2LineJSONData } from '../../types/Primitive'
import { arcPrimitiveGPU } from '../primitives/ArcPrimitiveGPU'
import { circlePrimitiveGPU } from '../primitives/CirclePrimitiveGPU'
import { linePrimitiveGPU } from '../primitives/LinePrimitiveGPU'
import { PtBufferBuilder } from './PtBufferBuilder'
import { SceneGPU } from './SceneGPU'
import { copyNumX, copyNumY, copyOffsetX, copyOffsetY } from './utils'

function copy(cb: (offsetX: number, offsetY: number) => void) {
	for (let i: number = 0; i < copyNumX; i++) {
		for (let j: number = 0; j < copyNumY; j++) {
			cb(i * copyOffsetX, j * copyOffsetY)
		}
	}
}

export class PlaneGPU {
	public scene: SceneGPU
	public id: number
	public builder: PtBufferBuilder
	public elementsMap: Map<string, number>
	constructor(scene: SceneGPU) {
		this.scene = scene
		this.id = 0
		this.builder = new PtBufferBuilder(scene.gpu)
		this.elementsMap = new Map()
	}

	// public getOrInitId() {
	// 	return this.initId()
	// }

	public initId() {
		this.id = this.scene.getPlaneId()
		return this.id
	}

	public removePt(id: number) {
		const result = this.builder.removePt(id)
		console.warn(result)
	}

	public removePts(ids: Array<number>) {
		for (let i = 0; i < ids.length; i++) {
			this.removePt(ids[i])
		}
	}

	public addPt(pt: Float32Array) {
		const id = this.builder.addPt(pt)
		return id
	}

	public createLine(primitiveItemValueData: TElementD2LineJSONData) {
		let id: number = undefined!
		copy((offsetX, offsetY) => {
			id = this.addPt(linePrimitiveGPU.create(this.id, primitiveItemValueData))
		})
		return id
	}

	public createCircle(primitiveItemValueData: TElementD2CircleJSONData) {
		let id: number = undefined!
		copy((offsetX, offsetY) => {
			id = this.addPt(circlePrimitiveGPU.create(this.id, primitiveItemValueData))
		})
		return id
	}

	public createArc(primitiveItemValueData: TElementD2ArcJSONData) {
		let id: number = undefined!
		copy((offsetX, offsetY) => {
			id = this.addPt(arcPrimitiveGPU.create(this.id, primitiveItemValueData))
		})
		return id
	}

	public addD2LineItems(targetPrimitives: Map<string, TElementD2LineJSONData>) {
		for (let [key, primitiveItemValueData] of targetPrimitives) {
			const id = this.createLine(primitiveItemValueData)
			this.elementsMap.set(key, id)
		}
	}

	public updateD2LineItems(targetPrimitives: Map<string, TElementD2LineJSONData>): void {
		for (let [key, primitiveItemValueData] of targetPrimitives) {
			const id = this.elementsMap.get(key)!
			this.builder.updatePt(id, linePrimitiveGPU.create(this.id, primitiveItemValueData))
		}
	}
	public deleteD2LineItems(targetIds: Set<string>): void {
		const arrTargetIds: Array<string> = Array.from(targetIds)
		for (let i: number = 0; i < arrTargetIds.length; i++) {
			const id = this.elementsMap.get(arrTargetIds[i])!
			this.builder.removePt(id)
		}
	}

	public addD2CircleItems(targetPrimitives: Map<string, TElementD2CircleJSONData>) {
		for (let [key, primitiveItemValueData] of targetPrimitives) {
			const id = this.createCircle(primitiveItemValueData)
			this.elementsMap.set(key, id)
		}
	}

	public updateD2CircleItems(targetPrimitives: Map<string, TElementD2CircleJSONData>): void {
		for (let [key, primitiveItemValueData] of targetPrimitives) {
			const id = this.elementsMap.get(key)!
			this.builder.updatePt(id, circlePrimitiveGPU.create(this.id, primitiveItemValueData))
		}
	}
	public deleteD2CircleItems(targetIds: Set<string>): void {
		const arrTargetIds: Array<string> = Array.from(targetIds)
		for (let i: number = 0; i < arrTargetIds.length; i++) {
			const id = this.elementsMap.get(arrTargetIds[i])!
			this.builder.removePt(id)
		}
	}

	public addD2ArcItems(targetPrimitives: Map<string, TElementD2ArcJSONData>) {
		for (let [key, primitiveItemValueData] of targetPrimitives) {
			const id = this.createArc(primitiveItemValueData)
			this.elementsMap.set(key, id)
		}
	}

	public updateD2ArcItems(targetPrimitives: Map<string, TElementD2ArcJSONData>): void {
		for (let [key, primitiveItemValueData] of targetPrimitives) {
			const id = this.elementsMap.get(key)!
			this.builder.updatePt(id, arcPrimitiveGPU.create(this.id, primitiveItemValueData))
		}
	}
	public deleteD2ArcItems(targetIds: Set<string>): void {
		const arrTargetIds: Array<string> = Array.from(targetIds)
		for (let i: number = 0; i < arrTargetIds.length; i++) {
			const id = this.elementsMap.get(arrTargetIds[i])!
			this.builder.removePt(id)
		}
	}

	public async render() {
		const result = await this.builder.build()
		const { startIndexsBuf, ptsBuf } = this.builder.update()
	}
}
