export type GPUBuffer = any
export type GPUBufferUsageFlags = any
export type GPUSize64 = any
export type GPUTextureFormat = any
export type GPUDevice = any
export type GPUCommandEncoder = any
