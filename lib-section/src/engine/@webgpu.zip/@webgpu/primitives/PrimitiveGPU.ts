export const MaxPtLength = 16

export const PtTypeShift = 10

export const PtTypeMask = (2 ** 4 - 1) << PtTypeShift
export const PlaneIdMask = 2 ** PtTypeShift - 1
export const OrderMask = 1 << (PtTypeShift + 4)
export const ColorMask = 1 << (PtTypeShift + 5)
export const HiddenMask = 1 << (PtTypeShift + 6)
export const AntiHiddenMask = 2 ** 32 - 1 - HiddenMask

export enum PtType {
	D2_LINE = 0,
	D2_CIRCLE = 1,
	/* ... */
	TYPE_NUM = 2,
}

function getType(num: number): number {
	return (num & PtTypeMask) >> PtTypeShift
}

const PtLengthMap = new Float64Array(PtType.TYPE_NUM)

export abstract class PrimitiveGPU {
	public length: number
	constructor(type: PtType, length: number) {
		this.length = length
		PtLengthMap[type] = length
	}

	abstract create(planeId: number, ...args: Array<any>): Float32Array
}

export const PtTools = {
	getPtLength(head: number) {
		return PtLengthMap[getType(head)] + ((head & OrderMask) === 0 ? 0 : 1) + ((head & ColorMask) === 0 ? 0 : 1)
	},
}
