import { TColorRGBAJSON } from '../../common/utils/Color'
import { TElementD2CircleJSONData } from '../../types/Primitive'
import { PrimitiveGPU, PtType } from './PrimitiveGPU'

export const LINE_VERTEX_LENGTH: number = 12

class CirclePrimitiveGPU extends PrimitiveGPU {
	constructor() {
		super(PtType.D2_CIRCLE, LINE_VERTEX_LENGTH)
	}

	public create(planeId: number, primitiveItemValueData: TElementD2CircleJSONData): Float32Array {
		const fillColorData: TColorRGBAJSON = primitiveItemValueData.fillColorData ? primitiveItemValueData.fillColorData : { r: 0, g: 0, b: 0, a: 0 }
		const typedArray: Array<number> = [
			planeId,
			primitiveItemValueData.centerPoint.x,
			primitiveItemValueData.centerPoint.y,
			primitiveItemValueData.centerPoint.z,
			primitiveItemValueData.radius,
			primitiveItemValueData.strokeWidth,
			primitiveItemValueData.strokeColorData.r,
			primitiveItemValueData.strokeColorData.g,
			primitiveItemValueData.strokeColorData.b,
			primitiveItemValueData.strokeColorData.a,
			primitiveItemValueData.isFill ? 1 : 0,
			fillColorData.r,
			fillColorData.g,
			fillColorData.b,
			fillColorData.a,
		]
		return new Float32Array(typedArray)
	}
}

export const circlePrimitiveGPU: CirclePrimitiveGPU = new CirclePrimitiveGPU()
