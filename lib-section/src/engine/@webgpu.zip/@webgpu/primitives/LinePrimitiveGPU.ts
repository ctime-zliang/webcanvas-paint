import { TElementD2LineJSONData } from '../../types/Primitive'
import { PrimitiveGPU, PtType } from './PrimitiveGPU'

export const LINE_VERTEX_LENGTH: number = 12

class LinePrimitiveGPU extends PrimitiveGPU {
	constructor() {
		super(PtType.D2_LINE, LINE_VERTEX_LENGTH)
	}

	public create(planeId: number, primitiveItemValueData: TElementD2LineJSONData): Float32Array {
		const typedArray: Array<number> = [
			planeId,
			primitiveItemValueData.startPoint.x,
			primitiveItemValueData.startPoint.y,
			primitiveItemValueData.startPoint.z,
			primitiveItemValueData.endPoint.x,
			primitiveItemValueData.endPoint.y,
			primitiveItemValueData.endPoint.z,
			primitiveItemValueData.strokeWidth,
			primitiveItemValueData.strokeColorData.r,
			primitiveItemValueData.strokeColorData.g,
			primitiveItemValueData.strokeColorData.b,
			primitiveItemValueData.strokeColorData.a,
		]
		return new Float32Array(typedArray)
	}
}

export const linePrimitiveGPU: LinePrimitiveGPU = new LinePrimitiveGPU()
