import { WebGPU } from './baseClass/WebGPU'
import { PlaneGPU } from './core/PlaneGPU'
import { SceneGPU } from './core/SceneGPU'

let webGPU: WebGPU
let sceneGPU: SceneGPU

export function createPlaneGPUItem(gl: WebGL2RenderingContext) {
	if (!webGPU) {
		webGPU = new WebGPU(gl, null!)
	}
	if (!sceneGPU) {
		sceneGPU = new SceneGPU(webGPU)
	}
	const planeGPU = new PlaneGPU(sceneGPU)
	return planeGPU
}
